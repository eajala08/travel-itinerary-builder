# Travel Itinerary Builder - Complete Build Guide
**Target Deadline: September 12, 2026**

---

## PHASE 0: Project Setup & Dependencies

### Step 0.1: Initialize Next.js Project
```bash
npx create-next-app@latest travel-itinerary \
  --typescript \
  --tailwind \
  --eslint \
  --app

cd travel-itinerary
```

Choose these options:
- Use TypeScript? **Yes**
- Use ESLint? **Yes**
- Use Tailwind CSS? **Yes**
- Use `src/` directory? **No** (easier file paths)
- Use App Router? **Yes**
- Would you like to customize the import alias? **No**

### Step 0.2: Install Dependencies
```bash
npm install \
  axios \
  zustand \
  leaflet \
  react-leaflet \
  jspdf \
  html2pdf.js \
  dotenv \
  lucide-react \
  date-fns

npm install --save-dev @types/leaflet @types/jspdf
```

### Step 0.3: Create Environment Variables File
Create `.env.local` in project root:
```
NEXT_PUBLIC_GOOGLE_PLACES_KEY=your_google_places_api_key
NEXT_PUBLIC_GEOAPIFY_KEY=your_geoapify_key
ANTHROPIC_API_KEY=your_anthropic_key
NEXT_PUBLIC_OPENWEATHER_KEY=your_openweather_key
NEXT_PUBLIC_OPENROUTE_KEY=your_openroute_key
```

**Get API Keys:**
1. **Anthropic:** https://console.anthropic.com → create account → get API key
2. **Google Places:** https://console.cloud.google.com → create project → enable Places API → create API key (restrict to Places)
3. **Geoapify:** https://myprojects.geoapify.com → sign up → get API key
4. **OpenWeather:** https://openweathermap.org/api → sign up → get free API key
5. **OpenRoute:** https://openrouteservice.org/dev/#/signup → sign up → get API key

### Step 0.4: Create Project Structure
```
travel-itinerary/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   ├── globals.css
│   └── api/
│       ├── generate-itinerary/
│       │   └── route.ts
│       ├── search-attractions/
│       │   └── route.ts
│       ├── search-restaurants/
│       │   └── route.ts
│       └── weather/
│           └── route.ts
├── components/
│   ├── InputForm.tsx
│   ├── ItineraryCard.tsx
│   ├── Map.tsx
│   ├── BudgetBreakdown.tsx
│   └── ExportButton.tsx
├── lib/
│   ├── types.ts
│   ├── store.ts
│   └── constants.ts
├── public/
├── .env.local
├── next.config.js
├── tailwind.config.ts
└── tsconfig.json
```

Run this to create the structure:
```bash
mkdir -p app/api/{generate-itinerary,search-attractions,search-restaurants,weather} components lib public
```

---

## PHASE 1: Core Data Types & State Management

### Step 1.1: Define TypeScript Types
**File: `lib/types.ts`**
```typescript
export interface ItineraryInput {
  destination: string;
  startDate: string;
  endDate: string;
  budget: number;
  interests: {
    food: boolean;
    fashion: boolean;
    sports: boolean;
    locationType: 'jungle' | 'beach' | 'city' | 'mountain' | 'countryside' | '';
    cultural: boolean;
    history: boolean;
    nightlife: boolean;
  };
  notes: string;
}

export interface Activity {
  time: string;
  name: string;
  type: 'temple' | 'museum' | 'market' | 'shopping' | 'food' | 'nature' | 'nightlife' | 'other';
  description: string;
  address: string;
  coords: { lat: number; lng: number };
  duration: string;
  estimatedCost: number;
  photos?: string[];
  rating?: number;
  source?: string;
}

export interface Meal {
  time: '08:00' | '12:30' | '18:30'; // breakfast, lunch, dinner
  type: 'breakfast' | 'lunch' | 'dinner';
  name: string;
  cuisine: string;
  address: string;
  coords: { lat: number; lng: number };
  budget: number;
  rating?: number;
  why: string;
  source?: string;
}

export interface DayItinerary {
  day: number;
  date: string;
  theme: string;
  activities: Activity[];
  meals: Meal[];
  weather?: WeatherData;
  dailySpend: {
    food: number;
    activities: number;
    transport: number;
    total: number;
  };
  travelTips?: string;
}

export interface ItineraryResponse {
  destination: string;
  dates: string[];
  durationDays: number;
  totalBudget: number;
  estimatedSpend: number;
  budgetBreakdown: {
    accommodation: number;
    food: number;
    activities: number;
    transport: number;
    buffer: number;
  };
  itinerary: DayItinerary[];
  mapPins: MapPin[];
  exportFormats: string[];
}

export interface MapPin {
  lat: number;
  lng: number;
  name: string;
  type: string;
  day?: number;
}

export interface WeatherData {
  date: string;
  condition: string;
  temp: number;
  humidity: number;
  advice: string;
}
```

### Step 1.2: Setup Zustand Store
**File: `lib/store.ts`**
```typescript
import { create } from 'zustand';
import { ItineraryInput, ItineraryResponse } from './types';

interface AppStore {
  input: ItineraryInput | null;
  itinerary: ItineraryResponse | null;
  loading: boolean;
  error: string | null;

  setInput: (input: ItineraryInput) => void;
  setItinerary: (itinerary: ItineraryResponse) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  reset: () => void;
}

const initialInput: ItineraryInput = {
  destination: '',
  startDate: '',
  endDate: '',
  budget: 2000,
  interests: {
    food: false,
    fashion: false,
    sports: false,
    locationType: '',
    cultural: false,
    history: false,
    nightlife: false,
  },
  notes: '',
};

export const useAppStore = create<AppStore>((set) => ({
  input: initialInput,
  itinerary: null,
  loading: false,
  error: null,

  setInput: (input) => set({ input }),
  setItinerary: (itinerary) => set({ itinerary }),
  setLoading: (loading) => set({ loading }),
  setError: (error) => set({ error }),
  reset: () => set({ input: initialInput, itinerary: null, error: null }),
}));
```

### Step 1.3: Constants & Utilities
**File: `lib/constants.ts`**
```typescript
export const INTERESTS = {
  food: 'Food',
  fashion: 'Fashion',
  sports: 'Sports',
  cultural: 'Cultural Experience',
  history: 'History/Museums',
  nightlife: 'Nightlife',
};

export const LOCATION_TYPES = [
  { value: 'jungle', label: 'Jungle' },
  { value: 'beach', label: 'Beach' },
  { value: 'city', label: 'City' },
  { value: 'mountain', label: 'Mountain' },
  { value: 'countryside', label: 'Countryside' },
];

export const ACTIVITY_TYPES = {
  temple: '🏯',
  museum: '🏛️',
  market: '🏪',
  shopping: '🛍️',
  food: '🍜',
  nature: '🌿',
  nightlife: '🎉',
  other: '📍',
};

export const MEAL_TIMES = {
  breakfast: { time: '08:00', label: 'Breakfast' },
  lunch: { time: '12:30', label: 'Lunch' },
  dinner: { time: '18:30', label: 'Dinner' },
};
```

---

## PHASE 2: Frontend - Input Form Component

### Step 2.1: Create Input Form Component
**File: `components/InputForm.tsx`**
```typescript
'use client';

import { useState } from 'react';
import { useAppStore } from '@/lib/store';
import { INTERESTS, LOCATION_TYPES } from '@/lib/constants';
import { ItineraryInput } from '@/lib/types';

export default function InputForm() {
  const { setInput, setLoading, setError, setItinerary } = useAppStore();
  const [formData, setFormData] = useState<ItineraryInput>({
    destination: '',
    startDate: '',
    endDate: '',
    budget: 2000,
    interests: {
      food: false,
      fashion: false,
      sports: false,
      locationType: '',
      cultural: false,
      history: false,
      nightlife: false,
    },
    notes: '',
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const validateForm = () => {
    const newErrors: Record<string, string> = {};

    if (!formData.destination.trim()) {
      newErrors.destination = 'Destination is required';
    }
    if (!formData.startDate) {
      newErrors.startDate = 'Start date is required';
    }
    if (!formData.endDate) {
      newErrors.endDate = 'End date is required';
    }
    if (formData.startDate && formData.endDate && formData.startDate > formData.endDate) {
      newErrors.dates = 'End date must be after start date';
    }
    if (formData.budget < 100) {
      newErrors.budget = 'Budget must be at least $100';
    }
    if (
      !Object.values(formData.interests).some(
        (v) => (typeof v === 'boolean' && v === true) || (typeof v === 'string' && v !== '')
      )
    ) {
      newErrors.interests = 'Select at least one interest';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setInput(formData);
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/generate-itinerary', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to generate itinerary');
      }

      const data = await response.json();
      setItinerary(data);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const handleCheckboxChange = (key: keyof typeof formData.interests) => {
    setFormData((prev) => ({
      ...prev,
      interests: {
        ...prev.interests,
        [key]: !prev.interests[key],
      },
    }));
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white rounded-lg shadow-md p-8 max-w-2xl mx-auto"
    >
      <h2 className="text-3xl font-bold mb-6 text-gray-800">Plan Your Trip</h2>

      {/* Destination */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Destination *
        </label>
        <input
          type="text"
          placeholder="e.g., Tokyo, Japan"
          value={formData.destination}
          onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
        />
        {errors.destination && <p className="text-red-500 text-sm mt-1">{errors.destination}</p>}
      </div>

      {/* Dates */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Start Date *
          </label>
          <input
            type="date"
            value={formData.startDate}
            onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
          {errors.startDate && <p className="text-red-500 text-sm mt-1">{errors.startDate}</p>}
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            End Date *
          </label>
          <input
            type="date"
            value={formData.endDate}
            onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
          {errors.endDate && <p className="text-red-500 text-sm mt-1">{errors.endDate}</p>}
        </div>
      </div>
      {errors.dates && <p className="text-red-500 text-sm mb-6">{errors.dates}</p>}

      {/* Budget */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Total Budget (USD) *
        </label>
        <div className="flex items-center">
          <span className="text-gray-600 mr-2">$</span>
          <input
            type="number"
            min="100"
            step="100"
            value={formData.budget}
            onChange={(e) => setFormData({ ...formData, budget: parseInt(e.target.value) })}
            className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
          />
        </div>
        {errors.budget && <p className="text-red-500 text-sm mt-1">{errors.budget}</p>}
      </div>

      {/* Location Type */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Location Type
        </label>
        <div className="flex flex-wrap gap-2">
          {LOCATION_TYPES.map((type) => (
            <button
              key={type.value}
              type="button"
              onClick={() =>
                setFormData((prev) => ({
                  ...prev,
                  interests: {
                    ...prev.interests,
                    locationType:
                      prev.interests.locationType === type.value ? '' : type.value,
                  },
                }))
              }
              className={`px-4 py-2 rounded-full font-medium transition ${
                formData.interests.locationType === type.value
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              {type.label}
            </button>
          ))}
        </div>
      </div>

      {/* Interests */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-3">
          Interests (select at least one) *
        </label>
        <div className="grid grid-cols-2 gap-3">
          {Object.entries(INTERESTS).map(([key, label]) => (
            <label key={key} className="flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={formData.interests[key as keyof typeof formData.interests] as boolean}
                onChange={() =>
                  handleCheckboxChange(key as keyof typeof formData.interests)
                }
                className="w-4 h-4 accent-blue-600"
              />
              <span className="ml-2 text-gray-700">{label}</span>
            </label>
          ))}
        </div>
        {errors.interests && <p className="text-red-500 text-sm mt-2">{errors.interests}</p>}
      </div>

      {/* Notes */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Additional Notes
        </label>
        <textarea
          placeholder="e.g., solo traveler, prefer group activities, dietary restrictions..."
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          rows={3}
          className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none"
        />
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        className="w-full bg-blue-600 text-white font-bold py-3 rounded-lg hover:bg-blue-700 transition text-lg"
      >
        Generate Itinerary
      </button>
    </form>
  );
}
```

---

## PHASE 3: Backend - API Routes

### Step 3.1: Anthropic Claude API Integration
**File: `app/api/generate-itinerary/route.ts`**

```typescript
import { Anthropic } from '@anthropic-ai/sdk';
import { ItineraryInput, ItineraryResponse } from '@/lib/types';
import { NextRequest, NextResponse } from 'next/server';

const client = new Anthropic();

async function generateItineraryFromClaude(input: ItineraryInput): Promise<ItineraryResponse> {
  const interestsList = Object.entries(input.interests)
    .filter(([_, value]) => {
      if (typeof value === 'boolean') return value;
      if (typeof value === 'string') return value !== '';
      return false;
    })
    .map(([key, _]) => {
      if (key === 'food') return 'local street food & dining';
      if (key === 'fashion') return 'shopping & fashion';
      if (key === 'sports') return 'sports & outdoor activities';
      if (key === 'cultural') return 'cultural experiences & local life';
      if (key === 'history') return 'history & museums';
      if (key === 'nightlife') return 'nightlife & entertainment';
      if (key === 'locationType') return `${value} environment`;
      return key;
    })
    .join(', ');

  const startDate = new Date(input.startDate);
  const endDate = new Date(input.endDate);
  const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24)) + 1;

  const dailyBudget = input.budget / days;
  const accommodationPerDay = 60;
  const foodPerDay = Math.floor(dailyBudget * 0.35);
  const activitiesPerDay = Math.floor(dailyBudget * 0.35);
  const transportPerDay = Math.floor(dailyBudget * 0.15);

  const prompt = `
You are an expert travel planner. Generate a detailed, personalized day-by-day itinerary.

DESTINATION: ${input.destination}
DATES: ${input.startDate} to ${input.endDate} (${days} days)
TOTAL BUDGET: $${input.budget}
INTERESTS: ${interestsList}
NOTES: ${input.notes || 'No additional notes'}

BUDGET ALLOCATION PER DAY:
- Accommodation: $${accommodationPerDay}
- Food: $${foodPerDay}
- Activities: $${activitiesPerDay}
- Transport: $${transportPerDay}

REQUIREMENTS:
1. Generate exactly ${days} days of itinerary
2. Each day MUST include:
   - theme (2-4 words describing the day's focus)
   - 2-4 activities with times, names, descriptions, real-world addresses, estimated costs
   - 3 meals (breakfast ~8am, lunch ~12:30pm, dinner ~6:30pm) with restaurant names, cuisines, budgets
   - realistic travel times between locations
   - daily cost summary
3. Balance activities based on user interests
4. Prioritize authentic, local experiences mixed with well-known attractions
5. Respect budget limits strictly
6. Account for rest/flexibility time
7. Vary meal types (street food, local restaurants, fine dining) based on interests

OUTPUT FORMAT (VALID JSON ONLY, no markdown, no code blocks):
{
  "destination": "${input.destination}",
  "dates": [${Array.from({ length: days }, (_, i) => {
    const date = new Date(startDate);
    date.setDate(date.getDate() + i);
    return `"${date.toISOString().split('T')[0]}"`;
  }).join(', ')}],
  "durationDays": ${days},
  "totalBudget": ${input.budget},
  "estimatedSpend": ${input.budget - 50},
  "budgetBreakdown": {
    "accommodation": ${accommodationPerDay * days},
    "food": ${foodPerDay * days},
    "activities": ${activitiesPerDay * days},
    "transport": ${transportPerDay * days},
    "buffer": 50
  },
  "itinerary": [
    {
      "day": 1,
      "date": "${new Date(startDate).toISOString().split('T')[0]}",
      "theme": "EXAMPLE: Temples & Shrines",
      "activities": [
        {
          "time": "09:00",
          "name": "Activity Name",
          "type": "temple",
          "description": "Brief description",
          "address": "Full street address",
          "coords": {"lat": 35.123, "lng": 139.456},
          "duration": "1.5h",
          "estimatedCost": 0,
          "photos": [],
          "rating": 4.5,
          "source": "local_knowledge"
        }
      ],
      "meals": [
        {
          "time": "08:00",
          "type": "breakfast",
          "name": "Restaurant Name",
          "cuisine": "Japanese",
          "address": "Full address",
          "coords": {"lat": 35.123, "lng": 139.456},
          "budget": 10,
          "rating": 4.5,
          "why": "Why this spot fits the itinerary",
          "source": "local_knowledge"
        }
      ],
      "weather": {
        "date": "2025-09-15",
        "condition": "Partly Cloudy",
        "temp": 22,
        "humidity": 60,
        "advice": "Bring light jacket"
      },
      "dailySpend": {
        "food": 30,
        "activities": 25,
        "transport": 10,
        "total": 65
      },
      "travelTips": "Start early to avoid crowds"
    }
  ],
  "mapPins": [
    {"lat": 35.123, "lng": 139.456, "name": "Activity Name", "type": "temple", "day": 1}
  ],
  "exportFormats": ["pdf", "ics", "json"]
}

CRITICAL: Output ONLY the JSON object, with no markdown backticks, no preamble, no explanation.
  `;

  const message = await client.messages.create({
    model: 'claude-3-5-sonnet-20241022',
    max_tokens: 4096,
    messages: [
      {
        role: 'user',
        content: prompt,
      },
    ],
  });

  const content = message.content[0];
  if (content.type !== 'text') {
    throw new Error('Unexpected response type from Claude');
  }

  try {
    const itinerary = JSON.parse(content.text) as ItineraryResponse;
    return itinerary;
  } catch (err) {
    console.error('Failed to parse Claude response:', content.text);
    throw new Error('Failed to parse itinerary response');
  }
}

export async function POST(request: NextRequest) {
  try {
    const input: ItineraryInput = await request.json();

    if (!process.env.ANTHROPIC_API_KEY) {
      return NextResponse.json(
        { error: 'ANTHROPIC_API_KEY is not configured' },
        { status: 500 }
      );
    }

    const itinerary = await generateItineraryFromClaude(input);

    return NextResponse.json(itinerary);
  } catch (error) {
    console.error('Error generating itinerary:', error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : 'Failed to generate itinerary' },
      { status: 500 }
    );
  }
}
```

### Step 3.2: Search Attractions API
**File: `app/api/search-attractions/route.ts`**

```typescript
import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';

interface OverpassResult {
  elements: Array<{
    id: number;
    lat: number;
    lon: number;
    tags: Record<string, string>;
  }>;
}

async function searchOverpass(query: string, destination: string): Promise<OverpassResult> {
  const overpassQuery = `
    [bbox:-90,-180,90,180];
    (
      ${query};
    );
    out center;
  `;

  const response = await axios.post('https://overpass-api.de/api/interpreter', overpassQuery, {
    timeout: 10000,
  });

  return response.data;
}

async function searchGooglePlaces(
  query: string,
  destination: string
): Promise<Array<{ name: string; lat: number; lng: number; rating: number }>> {
  if (!process.env.NEXT_PUBLIC_GOOGLE_PLACES_KEY) {
    return [];
  }

  try {
    const response = await axios.get(
      `https://places.googleapis.com/v1/places:searchText`,
      {
        headers: {
          'X-Goog-Api-Key': process.env.NEXT_PUBLIC_GOOGLE_PLACES_KEY,
          'Content-Type': 'application/json',
        },
        params: {
          textQuery: `${query} in ${destination}`,
        },
      }
    );

    return response.data.places?.map((place: any) => ({
      name: place.displayName?.text,
      lat: place.location?.latitude,
      lng: place.location?.longitude,
      rating: place.rating,
    })) || [];
  } catch (err) {
    console.error('Google Places API error:', err);
    return [];
  }
}

export async function POST(request: NextRequest) {
  try {
    const { query, destination } = await request.json();

    // Priority: Overpass (free, unlimited) + fallback to Google Places
    const overpassResults = await searchOverpass(
      `[name~"${query}", i]`,
      destination
    ).catch(() => ({ elements: [] }));

    const googleResults = await searchGooglePlaces(query, destination);

    const combined = [
      ...overpassResults.elements.slice(0, 5).map((el) => ({
        name: el.tags?.name || 'Unknown',
        lat: el.lat,
        lng: el.lon,
        source: 'overpass',
      })),
      ...googleResults.slice(0, 5).map((place) => ({
        name: place.name,
        lat: place.lat,
        lng: place.lng,
        rating: place.rating,
        source: 'google',
      })),
    ];

    return NextResponse.json({ attractions: combined });
  } catch (error) {
    console.error('Error searching attractions:', error);
    return NextResponse.json(
      { error: 'Failed to search attractions' },
      { status: 500 }
    );
  }
}
```

### Step 3.3: Search Restaurants API
**File: `app/api/search-restaurants/route.ts`**

```typescript
import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';

async function searchGooglePlacesRestaurants(destination: string, cuisine?: string) {
  if (!process.env.NEXT_PUBLIC_GOOGLE_PLACES_KEY) {
    return [];
  }

  try {
    const query = cuisine ? `${cuisine} restaurants in ${destination}` : `restaurants in ${destination}`;

    const response = await axios.get(
      `https://places.googleapis.com/v1/places:searchText`,
      {
        headers: {
          'X-Goog-Api-Key': process.env.NEXT_PUBLIC_GOOGLE_PLACES_KEY,
          'Content-Type': 'application/json',
        },
        params: {
          textQuery: query,
          maxResultCount: 10,
        },
      }
    );

    return response.data.places?.map((place: any) => ({
      name: place.displayName?.text,
      lat: place.location?.latitude,
      lng: place.location?.longitude,
      rating: place.rating,
      address: place.formattedAddress,
      priceLevel: place.priceLevel,
      photos: place.photos?.[0]?.name,
      source: 'google',
    })) || [];
  } catch (err) {
    console.error('Google Places restaurant search error:', err);
    return [];
  }
}

export async function POST(request: NextRequest) {
  try {
    const { destination, cuisine } = await request.json();

    const restaurants = await searchGooglePlacesRestaurants(destination, cuisine);

    return NextResponse.json({ restaurants });
  } catch (error) {
    console.error('Error searching restaurants:', error);
    return NextResponse.json(
      { error: 'Failed to search restaurants' },
      { status: 500 }
    );
  }
}
```

### Step 3.4: Weather API
**File: `app/api/weather/route.ts`**

```typescript
import { NextRequest, NextResponse } from 'next/server';
import axios from 'axios';

interface WeatherResponse {
  list: Array<{
    dt: number;
    main: {
      temp: number;
      humidity: number;
    };
    weather: Array<{
      main: string;
      description: string;
    }>;
  }>;
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const lat = searchParams.get('lat');
    const lng = searchParams.get('lng');
    const startDate = searchParams.get('startDate');

    if (!lat || !lng || !startDate) {
      return NextResponse.json(
        { error: 'lat, lng, and startDate are required' },
        { status: 400 }
      );
    }

    if (!process.env.NEXT_PUBLIC_OPENWEATHER_KEY) {
      return NextResponse.json(
        { error: 'OpenWeather API key is not configured' },
        { status: 500 }
      );
    }

    const response = await axios.get(
      'https://api.openweathermap.org/data/2.5/forecast',
      {
        params: {
          lat,
          lon: lng,
          appid: process.env.NEXT_PUBLIC_OPENWEATHER_KEY,
          units: 'metric',
        },
      }
    );

    const weatherData = response.data as WeatherResponse;

    const startTime = new Date(startDate).getTime();
    const forecastsByDay = weatherData.list
      .filter((item) => {
        const itemTime = item.dt * 1000;
        const dayDiff = Math.floor((itemTime - startTime) / (1000 * 60 * 60 * 24));
        return dayDiff >= 0 && dayDiff < 5;
      })
      .reduce(
        (acc, item) => {
          const date = new Date(item.dt * 1000).toISOString().split('T')[0];
          if (!acc[date]) {
            acc[date] = item;
          }
          return acc;
        },
        {} as Record<string, (typeof weatherData.list)[0]>
      );

    const forecasts = Object.entries(forecastsByDay).map(([date, data]) => ({
      date,
      condition: data.weather[0].main,
      description: data.weather[0].description,
      temp: Math.round(data.main.temp),
      humidity: data.main.humidity,
      advice:
        data.weather[0].main === 'Rain'
          ? 'Bring umbrella and rain jacket'
          : data.main.temp > 28
            ? 'Stay hydrated, wear sunscreen'
            : 'Bring light layers',
    }));

    return NextResponse.json({ forecasts });
  } catch (error) {
    console.error('Error fetching weather:', error);
    return NextResponse.json(
      { error: 'Failed to fetch weather data' },
      { status: 500 }
    );
  }
}
```

---

## PHASE 4: Frontend - Display Components

### Step 4.1: Itinerary Card Component
**File: `components/ItineraryCard.tsx`**

```typescript
'use client';

import { DayItinerary } from '@/lib/types';
import { ACTIVITY_TYPES } from '@/lib/constants';
import { ChevronDown, MapPin, Clock, DollarSign } from 'lucide-react';
import { useState } from 'react';

interface ItineraryCardProps {
  day: DayItinerary;
}

export default function ItineraryCard({ day }: ItineraryCardProps) {
  const [isExpanded, setIsExpanded] = useState(true);

  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden mb-6">
      {/* Header */}
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full bg-gradient-to-r from-blue-500 to-blue-600 text-white p-4 flex justify-between items-center hover:bg-blue-700 transition"
      >
        <div className="text-left">
          <h3 className="text-xl font-bold">
            Day {day.day} - {day.date}
          </h3>
          <p className="text-blue-100">{day.theme}</p>
        </div>
        <ChevronDown
          size={24}
          className={`transform transition ${isExpanded ? 'rotate-180' : ''}`}
        />
      </button>

      {isExpanded && (
        <div className="p-6">
          {/* Weather */}
          {day.weather && (
            <div className="bg-blue-50 rounded-lg p-4 mb-6">
              <p className="text-sm text-gray-600">
                {day.weather.condition} • {day.weather.temp}°C • Humidity: {day.weather.humidity}%
              </p>
              <p className="text-sm font-medium text-gray-700 mt-2">{day.weather.advice}</p>
            </div>
          )}

          {/* Activities */}
          <div className="mb-6">
            <h4 className="font-bold text-lg mb-3 text-gray-800">Activities</h4>
            {day.activities.map((activity, idx) => (
              <div key={idx} className="bg-gray-50 rounded-lg p-4 mb-3">
                <div className="flex justify-between items-start mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">
                      {ACTIVITY_TYPES[activity.type] || '📍'}
                    </span>
                    <div>
                      <p className="font-bold text-gray-800">{activity.name}</p>
                      <p className="text-sm text-gray-600">{activity.time}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-green-600 font-bold">${activity.estimatedCost}</p>
                    <p className="text-xs text-gray-500">{activity.duration}</p>
                  </div>
                </div>
                <p className="text-sm text-gray-700 mb-2">{activity.description}</p>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin size={16} />
                  <span>{activity.address}</span>
                </div>
                {activity.rating && (
                  <p className="text-xs text-yellow-600 mt-2">⭐ {activity.rating}/5</p>
                )}
              </div>
            ))}
          </div>

          {/* Meals */}
          <div className="mb-6">
            <h4 className="font-bold text-lg mb-3 text-gray-800">Dining</h4>
            {day.meals.map((meal, idx) => (
              <div key={idx} className="bg-amber-50 rounded-lg p-4 mb-3">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <p className="font-bold text-gray-800">{meal.name}</p>
                    <p className="text-sm text-gray-600">
                      {meal.type.charAt(0).toUpperCase() + meal.type.slice(1)} • {meal.time}
                    </p>
                  </div>
                  <span className="text-green-600 font-bold">${meal.budget}</span>
                </div>
                <p className="text-sm text-gray-700 mb-2">{meal.cuisine}</p>
                <p className="text-sm text-gray-600 mb-2 italic">{meal.why}</p>
                <div className="flex items-center gap-2 text-sm text-gray-600">
                  <MapPin size={16} />
                  <span>{meal.address}</span>
                </div>
              </div>
            ))}
          </div>

          {/* Daily Summary */}
          <div className="bg-green-50 rounded-lg p-4 border-l-4 border-green-500">
            <p className="text-sm text-gray-600 mb-2">Daily Budget Summary</p>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="text-gray-600">Food</p>
                <p className="font-bold text-gray-800">${day.dailySpend.food}</p>
              </div>
              <div>
                <p className="text-gray-600">Activities</p>
                <p className="font-bold text-gray-800">${day.dailySpend.activities}</p>
              </div>
              <div>
                <p className="text-gray-600">Transport</p>
                <p className="font-bold text-gray-800">${day.dailySpend.transport}</p>
              </div>
              <div className="bg-white rounded p-2">
                <p className="text-gray-600">Daily Total</p>
                <p className="font-bold text-green-600">${day.dailySpend.total}</p>
              </div>
            </div>
          </div>

          {/* Travel Tips */}
          {day.travelTips && (
            <div className="mt-4 bg-yellow-50 rounded-lg p-3 border-l-4 border-yellow-500">
              <p className="text-sm text-yellow-800">
                <span className="font-bold">💡 Tip:</span> {day.travelTips}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
```

### Step 4.2: Map Component
**File: `components/Map.tsx`**

```typescript
'use client';

import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import L from 'leaflet';
import { MapPin } from '@/lib/types';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet icon issue
const markerIcon = new L.Icon({
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

interface MapProps {
  pins: MapPin[];
  destination?: string;
}

export default function Map({ pins, destination }: MapProps) {
  if (pins.length === 0) {
    return (
      <div className="bg-gray-200 rounded-lg h-96 flex items-center justify-center text-gray-600">
        No locations to display
      </div>
    );
  }

  // Calculate center
  const avgLat = pins.reduce((sum, p) => sum + p.lat, 0) / pins.length;
  const avgLng = pins.reduce((sum, p) => sum + p.lng, 0) / pins.length;

  return (
    <div className="rounded-lg overflow-hidden shadow-md h-96">
      <MapContainer
        center={[avgLat, avgLng]}
        zoom={13}
        style={{ height: '100%', width: '100%' }}
      >
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        {pins.map((pin, idx) => (
          <Marker key={idx} position={[pin.lat, pin.lng]} icon={markerIcon}>
            <Popup>
              <div>
                <p className="font-bold">{pin.name}</p>
                <p className="text-sm text-gray-600">{pin.type}</p>
                {pin.day && <p className="text-xs text-gray-500">Day {pin.day}</p>}
              </div>
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
```

### Step 4.3: Budget Breakdown Component
**File: `components/BudgetBreakdown.tsx`**

```typescript
'use client';

import { ItineraryResponse } from '@/lib/types';

interface BudgetBreakdownProps {
  itinerary: ItineraryResponse;
}

export default function BudgetBreakdown({ itinerary }: BudgetBreakdownProps) {
  const { budgetBreakdown, totalBudget, estimatedSpend } = itinerary;
  const remaining = totalBudget - estimatedSpend;
  const percentSpent = (estimatedSpend / totalBudget) * 100;

  const categories = [
    {
      name: 'Accommodation',
      amount: budgetBreakdown.accommodation,
      color: 'bg-blue-500',
      icon: '🏨',
    },
    {
      name: 'Food',
      amount: budgetBreakdown.food,
      color: 'bg-amber-500',
      icon: '🍽️',
    },
    {
      name: 'Activities',
      amount: budgetBreakdown.activities,
      color: 'bg-purple-500',
      icon: '🎫',
    },
    {
      name: 'Transport',
      amount: budgetBreakdown.transport,
      color: 'bg-green-500',
      icon: '🚆',
    },
    {
      name: 'Buffer',
      amount: budgetBreakdown.buffer,
      color: 'bg-gray-400',
      icon: '💰',
    },
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-6">
      <h3 className="text-2xl font-bold mb-6 text-gray-800">Budget Breakdown</h3>

      {/* Progress Bar */}
      <div className="mb-6">
        <div className="flex justify-between mb-2">
          <span className="font-medium text-gray-700">Total Budget Allocation</span>
          <span className="font-bold text-gray-800">
            ${estimatedSpend} / ${totalBudget}
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-4 overflow-hidden">
          <div
            className="bg-gradient-to-r from-green-500 to-blue-500 h-full transition-all"
            style={{ width: `${percentSpent}%` }}
          />
        </div>
        {remaining > 0 && (
          <p className="text-sm text-green-600 mt-2">💚 ${remaining} buffer remaining</p>
        )}
      </div>

      {/* Category Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {categories.map((category, idx) => (
          <div key={idx} className="bg-gray-50 rounded-lg p-4">
            <div className="flex items-center mb-2">
              <span className="text-2xl mr-2">{category.icon}</span>
              <p className="text-sm font-medium text-gray-700">{category.name}</p>
            </div>
            <p className="text-2xl font-bold text-gray-800">${category.amount}</p>
            <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
              <div
                className={`${category.color} h-full rounded-full`}
                style={{ width: `${(category.amount / totalBudget) * 100}%` }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Summary Stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-6 border-t">
        <div>
          <p className="text-sm text-gray-600">Days</p>
          <p className="text-2xl font-bold text-gray-800">{itinerary.durationDays}</p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Per Day (Avg)</p>
          <p className="text-2xl font-bold text-gray-800">
            ${Math.round(estimatedSpend / itinerary.durationDays)}
          </p>
        </div>
        <div>
          <p className="text-sm text-gray-600">Buffer</p>
          <p className="text-2xl font-bold text-green-600">${remaining}</p>
        </div>
      </div>
    </div>
  );
}
```

### Step 4.4: Export Button Component
**File: `components/ExportButton.tsx`**

```typescript
'use client';

import { ItineraryResponse } from '@/lib/types';
import { Download } from 'lucide-react';
import jsPDF from 'jspdf';

interface ExportButtonProps {
  itinerary: ItineraryResponse;
  destination: string;
  dates: string[];
}

export default function ExportButton({
  itinerary,
  destination,
  dates,
}: ExportButtonProps) {
  const handleExportPDF = () => {
    const doc = new jsPDF();
    let yPosition = 20;

    // Title
    doc.setFontSize(24);
    doc.text(`Itinerary: ${destination}`, 20, yPosition);
    yPosition += 10;

    // Dates
    doc.setFontSize(12);
    doc.setTextColor(100);
    doc.text(`${dates[0]} to ${dates[dates.length - 1]}`, 20, yPosition);
    yPosition += 15;

    // Budget Summary
    doc.setFontSize(14);
    doc.setTextColor(0);
    doc.text('Budget Summary', 20, yPosition);
    yPosition += 7;

    doc.setFontSize(10);
    doc.text(`Total Budget: $${itinerary.totalBudget}`, 20, yPosition);
    yPosition += 5;
    doc.text(`Estimated Spend: $${itinerary.estimatedSpend}`, 20, yPosition);
    yPosition += 10;

    // Breakdown
    doc.setFontSize(12);
    doc.text('Breakdown by Category', 20, yPosition);
    yPosition += 6;

    doc.setFontSize(9);
    Object.entries(itinerary.budgetBreakdown).forEach(([key, value]) => {
      doc.text(`${key.charAt(0).toUpperCase() + key.slice(1)}: $${value}`, 20, yPosition);
      yPosition += 5;
    });

    yPosition += 10;

    // Days
    itinerary.itinerary.forEach((day) => {
      if (yPosition > 250) {
        doc.addPage();
        yPosition = 20;
      }

      doc.setFontSize(14);
      doc.setTextColor(0);
      doc.text(`Day ${day.day} - ${day.theme}`, 20, yPosition);
      yPosition += 7;

      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(day.date, 20, yPosition);
      yPosition += 7;

      // Activities
      doc.setFontSize(11);
      doc.setTextColor(0);
      doc.text('Activities:', 20, yPosition);
      yPosition += 5;

      doc.setFontSize(9);
      day.activities.slice(0, 2).forEach((activity) => {
        doc.text(`• ${activity.time} - ${activity.name} ($${activity.estimatedCost})`, 25, yPosition);
        yPosition += 5;
      });

      // Meals
      yPosition += 3;
      doc.setFontSize(11);
      doc.setTextColor(0);
      doc.text('Meals:', 20, yPosition);
      yPosition += 5;

      doc.setFontSize(9);
      day.meals.forEach((meal) => {
        doc.text(`• ${meal.type}: ${meal.name} ($${meal.budget})`, 25, yPosition);
        yPosition += 5;
      });

      yPosition += 5;
    });

    doc.save(`${destination}-itinerary.pdf`);
  };

  const handleExportJSON = () => {
    const dataStr = JSON.stringify(itinerary, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${destination}-itinerary.json`;
    a.click();
  };

  return (
    <div className="flex gap-3">
      <button
        onClick={handleExportPDF}
        className="flex items-center gap-2 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition font-medium"
      >
        <Download size={18} />
        Export PDF
      </button>
      <button
        onClick={handleExportJSON}
        className="flex items-center gap-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition font-medium"
      >
        <Download size={18} />
        Export JSON
      </button>
    </div>
  );
}
```

---

## PHASE 5: Main Page & Layout

### Step 5.1: Global Styles
**File: `app/globals.css`**

```css
@tailwind base;
@tailwind components;
@tailwind utilities;

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Oxygen',
    'Ubuntu', 'Cantarell', 'Fira Sans', 'Droid Sans', 'Source Sans Pro',
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  background-color: #f8f9fa;
}

html {
  scroll-behavior: smooth;
}

input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

input[type='number'] {
  -moz-appearance: textfield;
}
```

### Step 5.2: Root Layout
**File: `app/layout.tsx`**

```typescript
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Travel Itinerary Builder',
  description: 'AI-powered travel itinerary generator',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-gray-50">
        <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white shadow-lg">
          <div className="max-w-6xl mx-auto px-4 py-6">
            <h1 className="text-4xl font-bold">✈️ Travel Itinerary Builder</h1>
            <p className="text-blue-100 mt-2">
              AI-powered personalized trip planning in seconds
            </p>
          </div>
        </header>

        <main className="max-w-6xl mx-auto px-4 py-8">
          {children}
        </main>

        <footer className="bg-gray-800 text-white text-center py-4 mt-12">
          <p>Built with Claude API • React • Next.js • Tailwind CSS</p>
        </footer>
      </body>
    </html>
  );
}
```

### Step 5.3: Home Page
**File: `app/page.tsx`**

```typescript
'use client';

import { useAppStore } from '@/lib/store';
import InputForm from '@/components/InputForm';
import ItineraryCard from '@/components/ItineraryCard';
import BudgetBreakdown from '@/components/BudgetBreakdown';
import Map from '@/components/Map';
import ExportButton from '@/components/ExportButton';
import { Loader } from 'lucide-react';

export default function Home() {
  const { loading, error, itinerary } = useAppStore();

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center min-h-screen">
        <Loader className="animate-spin text-blue-600 mb-4" size={48} />
        <p className="text-xl text-gray-700">Generating your personalized itinerary...</p>
        <p className="text-gray-500 mt-2">This may take up to 30 seconds</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 rounded-lg p-6 mb-6">
        <h2 className="text-xl font-bold text-red-800 mb-2">Error</h2>
        <p className="text-red-700">{error}</p>
        <button
          onClick={() => window.location.reload()}
          className="mt-4 bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700"
        >
          Try Again
        </button>
      </div>
    );
  }

  if (!itinerary) {
    return (
      <div>
        <InputForm />
      </div>
    );
  }

  return (
    <div>
      {/* Summary Section */}
      <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-lg shadow-md p-8 mb-8">
        <h2 className="text-3xl font-bold text-gray-800 mb-2">
          {itinerary.destination}
        </h2>
        <p className="text-gray-600 mb-4">
          {itinerary.dates[0]} to {itinerary.dates[itinerary.dates.length - 1]} •{' '}
          {itinerary.durationDays} days
        </p>
        <div className="mb-6">
          <ExportButton
            itinerary={itinerary}
            destination={itinerary.destination}
            dates={itinerary.dates}
          />
        </div>
      </div>

      {/* Budget Breakdown */}
      <BudgetBreakdown itinerary={itinerary} />

      {/* Map */}
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">Trip Map</h3>
        <Map pins={itinerary.mapPins} destination={itinerary.destination} />
      </div>

      {/* Itinerary Days */}
      <div className="mb-8">
        <h3 className="text-2xl font-bold text-gray-800 mb-4">Day-by-Day Itinerary</h3>
        {itinerary.itinerary.map((day) => (
          <ItineraryCard key={day.day} day={day} />
        ))}
      </div>

      {/* Export Section */}
      <div className="bg-blue-50 rounded-lg p-6 text-center mb-8">
        <h3 className="text-xl font-bold text-gray-800 mb-4">Save Your Itinerary</h3>
        <ExportButton
          itinerary={itinerary}
          destination={itinerary.destination}
          dates={itinerary.dates}
        />
      </div>
    </div>
  );
}
```

---

## PHASE 6: Configuration Files

### Step 6.1: Next.js Config
**File: `next.config.js`**

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.githubusercontent.com',
      },
      {
        protocol: 'https',
        hostname: 'upload.wikimedia.org',
      },
      {
        protocol: 'https',
        hostname: 'maps.googleapis.com',
      },
    ],
  },
};

module.exports = nextConfig;
```

### Step 6.2: TypeScript Config
**File: `tsconfig.json`** (should be auto-generated, verify these paths)

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "jsx": "react-jsx",
    "module": "ESNext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "allowJs": true,
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "isolatedModules": true,
    "noEmit": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx", ".next/types/**/*.ts"],
  "exclude": ["node_modules"]
}
```

### Step 6.3: Tailwind Config
**File: `tailwind.config.ts`** (should be auto-generated)

```typescript
import type { Config } from 'tailwindcss';

const config: Config = {
  content: [
    './app/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        primary: '#3B82F6',
        secondary: '#8B5CF6',
      },
    },
  },
  plugins: [],
};
export default config;
```

---

## PHASE 7: Testing & Debugging

### Step 7.1: Test the Full Flow

```bash
# 1. Start dev server
npm run dev

# 2. Open http://localhost:3000

# 3. Fill out form with test data:
# - Destination: "Bangkok, Thailand"
# - Start Date: 2025-09-20
# - End Date: 2025-09-23
# - Budget: 1500
# - Interests: Food, Cultural, History
# - Notes: "First time visitor, love street food, solo traveler"

# 4. Click "Generate Itinerary"

# 5. Verify:
# - No errors in console
# - Itinerary loads within 30 seconds
# - All days have activities and meals
# - Map displays locations
# - Budget breakdown is accurate
# - Export buttons work
```

### Step 7.2: Common Issues & Fixes

**Issue: API key errors**
```
Solution: Check .env.local has all keys
- ANTHROPIC_API_KEY must be set
- NEXT_PUBLIC_* keys must have NEXT_PUBLIC_ prefix
```

**Issue: Map not displaying**
```
Solution: Install Leaflet properly
npm install leaflet react-leaflet
Also check that MapContainer is inside a dynamic import if needed
```

**Issue: Claude returning invalid JSON**
```
Solution: Update the system prompt to be more strict
Add: "Output ONLY raw JSON with no markdown, no backticks, no explanation."
```

**Issue: API rate limits**
```
Solution: Add caching
- Cache Google Places results for 1 hour
- Use Overpass first (unlimited, free)
- Fallback to Google Places if needed
```

---

## PHASE 8: Deployment

### Step 8.1: Deploy to Vercel

```bash
# 1. Create Vercel account (if not already)
# https://vercel.com

# 2. Install Vercel CLI
npm i -g vercel

# 3. Login
vercel login

# 4. Deploy
vercel

# Follow prompts:
# - Link to GitHub repository? Y
# - Reuse existing project settings? N (for first-time)
# - Deploy to production? Y

# 5. Set environment variables in Vercel Dashboard
# Go to: Settings > Environment Variables
# Add all keys from .env.local:
# - ANTHROPIC_API_KEY
# - NEXT_PUBLIC_GOOGLE_PLACES_KEY
# - NEXT_PUBLIC_GEOAPIFY_KEY
# - NEXT_PUBLIC_OPENWEATHER_KEY
# - NEXT_PUBLIC_OPENROUTE_KEY

# 6. Trigger redeploy
vercel deploy --prod
```

### Step 8.2: Optimize for Production

```bash
# Run build locally first to catch errors
npm run build

# Check for warnings/errors
npm run lint
```

### Step 8.3: Monitor & Scale
- Watch Vercel dashboard for errors
- Check API usage limits (Google Places has 300/month free)
- Implement caching to reduce API calls
- Monitor Anthropic API usage

---

## PHASE 9: Post-Launch Enhancements

### Optional Features (If Time Permits)
1. **User Accounts:** Supabase + Auth
2. **Save Itineraries:** Store in Supabase PostgreSQL
3. **Share Links:** Generate unique URLs for sharing
4. **Real-time Booking:** Integrate with Booking.com API
5. **Multi-city:** Support multiple destinations in one trip
6. **Group Splitting:** Calculate per-person costs
7. **Accessibility:** Add alt text, ARIA labels

---

## Final Checklist Before Submission

- [ ] Code is clean and commented
- [ ] All API keys are in .env.local (not committed)
- [ ] App works on mobile (test on different screen sizes)
- [ ] PDF export generates valid PDFs
- [ ] No console errors
- [ ] Deployed to Vercel successfully
- [ ] README.md created with setup instructions
- [ ] Forms validate properly
- [ ] Error messages are user-friendly
- [ ] Loading states display correctly
- [ ] Map displays correctly on all days
- [ ] Budget breakdown is accurate

---

## Project Submission Checklist

1. **GitHub Repository:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit: Travel itinerary builder"
   git remote add origin <your-repo-url>
   git push -u origin main
   ```

2. **Create README.md:**
   ```markdown
   # Travel Itinerary Builder

   An AI-powered travel planning app that generates personalized itineraries.

   ## Features
   - Destination, date, and budget input
   - Interest-based curation (food, culture, history, etc.)
   - AI-generated day-by-day itinerary
   - Interactive map of all locations
   - Budget breakdown and cost tracking
   - PDF and JSON export

   ## Tech Stack
   - Frontend: Next.js, React, Tailwind CSS
   - Backend: Next.js API Routes
   - AI: Anthropic Claude API
   - APIs: Google Places, OpenWeather, Overpass, MediaWiki

   ## Setup
   1. Clone repo
   2. npm install
   3. Create .env.local with API keys
   4. npm run dev
   5. Open http://localhost:3000

   ## Deployment
   Deployed on Vercel: [your-vercel-url]
   ```

3. **Submit to Challenge:**
   - GitHub repo link
   - Live demo URL (Vercel)
   - Brief description of features

---

## Total Build Time Estimate
- **Day 1:** Phases 0-2 (Setup, types, input form) = 3-4 hours
- **Day 2:** Phases 3-4 (APIs, components, display) = 5-6 hours
- **Day 3:** Phases 5-8 (Integration, styling, deployment) = 4-5 hours

**Total: ~12-15 hours of active development**

**This is a realistic, polished, production-ready demo suitable for an AI challenge submission.**

Good luck! 🚀
