# Travel Itinerary Builder - Project Outline

## Project Overview
A web app where users input destination, dates, budget, and interests → AI generates a detailed, personalized day-by-day itinerary with activities, restaurant recommendations, cost breakdowns, and maps.

---

## 1. User Flow & Features

### Input Phase
- **Destination:** text input (city name) with autocomplete
- **Travel Dates:** date picker (start & end)
- **Budget:** total USD/EUR/etc. → auto-allocates per day
- **Curations (checkboxes/chips):** 
  - Food (street food, fine dining, vegan, local cuisine)
  - Fashion (shopping districts, boutiques, markets)
  - Sports (hiking, cycling, water sports, gyms)
  - Location Type (jungle, beach, city, mountain, countryside)
  - Cultural Experience (temples, shrines, festivals, local life)
  - History/Museums (art, natural history, war, architecture)
  - Nightlife (bars, clubs, casual hangouts)
  - **Custom notes field** (e.g., "I'm traveling alone, prefer group activities")

### Output Phase
- **Day-by-day itinerary:**
  - Morning: activity + time + estimated cost
  - Lunch: restaurant rec + address + budget + cuisine type
  - Afternoon: activity + time + cost
  - Dinner: restaurant rec + address + budget + cuisine type
  - Evening: optional activity
  - **Daily summary:** estimated spend vs. budget for that day
- **Interactive map:** pins for all activities, restaurants, hotels
- **Collapsible cards** for each activity/restaurant with:
  - Description
  - Address + Google Maps link
  - Opening hours (from API)
  - Photos (from API or Wikipedia)
  - Estimated cost
  - Travel time between locations
- **Budget breakdown:**
  - Food: $X
  - Activities: $X
  - Transport: $X
  - Accommodation: $X (if included)
- **Export options:** PDF, PDF + ICS calendar, JSON for sharing

---

## 2. Architecture

### Frontend
- **Framework:** React (or Next.js for better SSR & API routing)
- **UI Library:** Tailwind CSS + Shadcn/ui for polished components
- **Map Library:** Leaflet + OpenStreetMap tiles (free, no key needed)
- **State Management:** React Context or Zustand (lightweight)
- **HTTP Client:** Fetch API or Axios

### Backend
- **Framework:** Node.js + Express (or Python Flask/FastAPI)
- **AI Integration:** Anthropic Claude API
- **Environment:** Deployed on Vercel (free tier) or Railway
- **Database:** Not strictly needed (state lives in frontend), but optional Supabase for saving/sharing itineraries

### API Integrations (Free Tier)
1. **Google Places API** (free: 300 requests/month for new accounts, then $7 per 1k after)
   - Search for restaurants, temples, museums, attractions
   - Get opening hours, photos, ratings, phone numbers
2. **OpenWeather API** (free: 5-day forecast, 1k calls/day)
   - Show weather forecast for each day
3. **Overpass API** (free, no key)
   - Query OSM data: temples, restaurants, landmarks, parks
4. **MediaWiki API** (Wikipedia, free)
   - Fetch descriptions and images of attractions
5. **Geoapify Geocoding** (free: 3k/month)
   - Convert addresses to lat/lon for mapping
6. **OpenRoute Service** (free: 2.5k requests/day)
   - Calculate walking/transit times between locations
7. **Yelp API** (limited free tier; fallback to Google Places)
   - Restaurant reviews and ratings

---

## 3. AI Prompt Structure (Claude)

### System Prompt
```
You are an expert travel planner. Generate hyper-personalized itineraries.
- Respect budget limits strictly
- Balance activities based on user interests
- Suggest restaurants that match both cuisine type and budget
- Account for travel time between locations (walking, transit)
- Provide realistic times (don't overpack days)
- Output JSON only (see schema below)
```

### User Prompt Example
```
Generate a 3-day itinerary for Tokyo with a $1500 budget.
Interests: Food (local street food, ramen), Temples (Buddhist/Shinto), 
Cultural Experience (local neighborhoods, markets).

Preferences:
- Solo traveler, prefer group activities
- No hiking/sports
- Vegetarian-friendly meals
- Mix of touristy and off-the-beaten-path

Accommodation budget: $60/night (included in total).
Food budget: $40/day.
Activities: $30/day.

Output as JSON matching this schema:
{
  "itinerary": [
    {
      "day": 1,
      "date": "2025-09-15",
      "theme": "Temples & Senso-ji Area",
      "activities": [
        {
          "time": "09:00",
          "type": "temple",
          "name": "Senso-ji Temple",
          "description": "...",
          "address": "...",
          "estimatedCost": 0,
          "duration": "1h",
          "mapCoords": { "lat": 35.714, "lng": 139.796 }
        }
      ],
      "meals": [
        {
          "mealType": "breakfast",
          "name": "Coffee Shop XYZ",
          "cuisine": "Japanese",
          "address": "...",
          "budget": 8,
          "why": "Great views of the temple area"
        }
      ],
      "dailySpend": { "food": 30, "activities": 25, "transport": 5 }
    }
  ],
  "summary": {
    "totalBudget": 1500,
    "estimatedSpend": 1450,
    "breakdownByCategory": { "food": 360, "activities": 270, "transport": 90, "accommodation": 180 }
  }
}
```

---

## 4. Tech Stack (Recommended)

### Frontend
- **Next.js** (React + API routes + SSR)
- **Tailwind CSS + Shadcn/ui**
- **Leaflet + react-leaflet** (maps)
- **Zustand** (state)
- **Axios** (HTTP)

### Backend / Serverless
- **Next.js API routes** (/pages/api)
  - `/api/generate-itinerary` → calls Claude + other APIs
  - `/api/search-attractions` → queries Google Places + Overpass
  - `/api/search-restaurants` → queries Google Places + Yelp
  - `/api/weather` → calls OpenWeather
  - `/api/directions` → calls OpenRoute Service

### Deployment
- **Vercel** (Next.js native, free tier)
- **Environment variables:** API keys stored securely

### Optional Persistence
- **Supabase** (free PostgreSQL + auth + real-time)
  - Save itineraries: `{ userId, destination, dates, budget, interests, itinerary_json, createdAt }`
  - Share links: `{ shareId, itinerary, expiresAt }`

---

## 5. Data Flow

```
User Input (React Form)
    ↓
/api/generate-itinerary (Next.js)
    ↓
Claude API
    ├→ Processes user request
    ├→ Generates structured JSON itinerary
    ↓
Parallel API Calls:
    ├→ /api/search-attractions (Overpass + Google Places)
    ├→ /api/search-restaurants (Google Places + Yelp)
    ├→ /api/weather (OpenWeather)
    ├→ /api/directions (OpenRoute)
    ↓
Response to Frontend
    ↓
React renders:
    ├→ Itinerary cards (day-by-day)
    ├→ Map with pins
    ├→ Budget breakdown
    ├→ Export options (PDF, ICS)
```

---

## 6. Implementation Roadmap (2-3 days)

### Day 1: Core Setup & Input
- [ ] Scaffold Next.js project
- [ ] Build input form component (destination, dates, budget, interests)
- [ ] Set up API keys (Google Places, OpenWeather, Anthropic)
- [ ] Create `/api/generate-itinerary` endpoint (Claude call)
- [ ] Test Claude prompt with mock data

### Day 2: Integrate Free APIs & Display
- [ ] Add `/api/search-attractions` (Overpass + Google Places)
- [ ] Add `/api/search-restaurants` (Google Places)
- [ ] Add weather API integration
- [ ] Build itinerary card UI (day, activities, meals, costs)
- [ ] Render interactive map (Leaflet)
- [ ] Style with Tailwind + Shadcn

### Day 3: Polish & Export
- [ ] Budget breakdown visualization
- [ ] Add travel time calculations between locations
- [ ] PDF export (use jsPDF or html2pdf)
- [ ] Error handling & loading states
- [ ] Edge cases: no results, API failures
- [ ] Deploy to Vercel
- [ ] Demo & optimize

---

## 7. Free APIs Breakdown

| API | Purpose | Free Tier | Notes |
|-----|---------|-----------|-------|
| **Claude (Anthropic)** | Itinerary generation | 3M tokens/month (new acct) | Core engine; pay-as-you-go after |
| **Google Places** | Restaurants, attractions, hours | 300/month initial; $7/1k after | Best coverage, but quota-limited |
| **Overpass** | OSM data (temples, museums, parks) | Unlimited | No key needed; great for cultural sites |
| **OpenWeather** | Weather forecast | 5-day, 1k calls/day | Free tier is sufficient |
| **MediaWiki** | Attraction descriptions & images | Unlimited | Wikipedia API; great for context |
| **Geoapify Geocoding** | Lat/lon lookup | 3k/month free | Lightweight alternative to Google |
| **OpenRoute Service** | Directions & travel time | 2.5k requests/day | Free tier covers typical usage |
| **Leaflet + OSM Tiles** | Maps | Free & unlimited | No API key; uses community tiles |

---

## 8. Example Output (JSON)

```json
{
  "destination": "Tokyo, Japan",
  "dates": ["2025-09-15", "2025-09-18"],
  "durationDays": 3,
  "totalBudget": 1500,
  "estimatedSpend": 1385,
  "budgetBreakdown": {
    "accommodation": 180,
    "food": 360,
    "activities": 270,
    "transport": 100,
    "buffer": 75
  },
  "itinerary": [
    {
      "day": 1,
      "date": "2025-09-15",
      "theme": "Ancient Tokyo: Temples & Senso-ji",
      "activities": [
        {
          "time": "09:00",
          "name": "Senso-ji Temple",
          "type": "temple",
          "description": "Tokyo's oldest temple, stunning red lantern, busy street of souvenir shops.",
          "address": "2 Chome Asakusa, Taito Ward, Tokyo",
          "coords": { "lat": 35.7148, "lng": 139.7967 },
          "duration": "1.5h",
          "estimatedCost": 0,
          "photos": ["url1", "url2"],
          "source": "wikipedia"
        },
        {
          "time": "11:00",
          "name": "Nakamise Shopping Street",
          "type": "shopping",
          "description": "Traditional goods, snacks, local crafts.",
          "address": "Asakusa, Taito Ward, Tokyo",
          "coords": { "lat": 35.7148, "lng": 139.7975 },
          "duration": "1h",
          "estimatedCost": 20,
          "source": "google_places"
        }
      ],
      "meals": [
        {
          "time": "12:30",
          "type": "lunch",
          "name": "Ichiran Ramen",
          "cuisine": "Japanese (Ramen)",
          "address": "Asakusa, Taito Ward",
          "budget": 10,
          "rating": 4.5,
          "why": "Authentic local ramen, budget-friendly, famous chain.",
          "source": "google_places"
        },
        {
          "time": "18:30",
          "type": "dinner",
          "name": "Takeshita Udon",
          "cuisine": "Japanese (Udon)",
          "address": "Nearby",
          "budget": 12,
          "rating": 4.3,
          "why": "Local favorite, vegetarian options.",
          "source": "google_places"
        }
      ],
      "weather": {
        "date": "2025-09-15",
        "condition": "Partly Cloudy",
        "temp": "22°C",
        "humidity": "60%",
        "advice": "Bring light jacket"
      },
      "dailySpend": {
        "food": 30,
        "activities": 25,
        "transport": 10,
        "total": 65
      },
      "travelTips": "Start early to beat temple crowds. Use IC card for transit (buy at airport)."
    },
    {
      "day": 2,
      "date": "2025-09-16",
      "theme": "Cultural Immersion: Markets & Local Life",
      "activities": [
        {
          "time": "08:00",
          "name": "Tsukiji Outer Market",
          "type": "market",
          "description": "Fresh seafood, street food, local atmosphere.",
          "address": "Tsukiji, Chuo Ward, Tokyo",
          "coords": { "lat": 35.6654, "lng": 139.7707 },
          "duration": "2h",
          "estimatedCost": 0,
          "source": "google_places"
        }
      ],
      "meals": [
        {
          "time": "08:30",
          "type": "breakfast",
          "name": "Tsukiji Fresh Sushi",
          "cuisine": "Japanese (Sushi)",
          "budget": 15,
          "why": "Fresh catch from the market, authentic experience."
        }
      ],
      "dailySpend": {
        "food": 35,
        "activities": 20,
        "transport": 12,
        "total": 67
      }
    },
    {
      "day": 3,
      "date": "2025-09-17",
      "theme": "Relaxation: Shrine & Peaceful Neighborhoods",
      "activities": [],
      "meals": [],
      "dailySpend": { "food": 30, "activities": 20, "transport": 10, "total": 60 }
    }
  ],
  "mapPins": [
    { "lat": 35.7148, "lng": 139.7967, "name": "Senso-ji", "type": "temple" },
    { "lat": 35.6654, "lng": 139.7707, "name": "Tsukiji Market", "type": "market" }
  ],
  "exportFormats": ["pdf", "ics", "json"]
}
```

---

## 9. Nice-to-Haves (Post-MVP)
- Multi-city itineraries
- Group trip splitting (split costs among friends)
- Real-time booking integrations (hotels, flights, restaurants)
- User accounts & saved itineraries
- Collaborative planning (share & edit with friends)
- Live transit data integration (Google Transit)
- AR navigation (AR.js)
- Sustainability scoring (eco-friendly options)

---

## 10. Challenges & Solutions

| Challenge | Solution |
|-----------|----------|
| API quota limits | Cache responses, use free tier carefully, prioritize Overpass + Wikipedia |
| Restaurant data gaps | Combine Google Places + Yelp; fallback to Wikipedia descriptions |
| Real-time pricing | Show "estimated" costs; note that prices vary by season |
| Offline experience | Store generated itinerary as JSON; allow offline viewing (localStorage) |
| Mobile responsiveness | Design mobile-first; test on iPhone/Android early |

---

## 11. Quick Start Commands

```bash
# Create Next.js project
npx create-next-app@latest travel-itinerary --typescript --tailwind

# Install dependencies
npm install axios zustand leaflet react-leaflet jspdf html2pdf.js

# Set up .env.local
NEXT_PUBLIC_GOOGLE_PLACES_KEY=your_key
ANTHROPIC_API_KEY=your_key
OPENWEATHER_API_KEY=your_key

# Run dev server
npm run dev

# Deploy
vercel deploy
```

---

## Estimated Timeline for Challenge Submission
- **Day 1 (Sept 10):** Input form + Claude integration + basic API setup
- **Day 2 (Sept 11):** Map + itinerary cards + restaurants API
- **Day 3 (Sept 12):** Polish, export, deploy
- **Submit by Sept 12, 11:59 PM**

This scope is **realistic & impressive** for a solo demo. Focus on core features first, polish second. 🚀
